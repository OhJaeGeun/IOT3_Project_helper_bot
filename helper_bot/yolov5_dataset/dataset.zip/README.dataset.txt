# detect falling person > 2022-07-22 2:59pm
https://universe.roboflow.com/object-detection/detect-falling-person

Provided by Roboflow
License: Public Domain

